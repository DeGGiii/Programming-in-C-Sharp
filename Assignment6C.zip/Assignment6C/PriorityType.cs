﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment6C
{
    enum PriorityType
    {
        Very_imporant,
        Imporant,
        Normal,
        Less_imporant,
        Not_important
    }
}
